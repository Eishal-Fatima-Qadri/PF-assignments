#include<iostream>
using namespace std;
int main()
{
	int n = 0; int odd = 0; int even = 0;
	do
	{
		cout << "enter a number : " << endl;
		cin >> n;

		if (n > 0 && n % 2 == 0)
		{
			even++;
		}
		else if (n > 0 && n % 2 != 0)
		{
			odd++;
		}

	} while (n != -1);

	cout << "odd numbers = " << odd << endl;
	cout << "even numbers = " << even << endl;

	return 0;
}