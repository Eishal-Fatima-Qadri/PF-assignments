#include<iostream>
using namespace std;
int main()
{
	int SUM1 = 0; int SUM2 = 0; int T_SUM = 0;
	int i = 501;
	while (i < 3000)
	{
		if (i % 3 == 0 && i % 5 != 0)
		{
			SUM1 = SUM1 + i;
		}
		if (i % 5 == 0 && i % 3 != 0)
		{
			SUM1 = SUM1 + i;
		}
		i++;
	}
	cout << "TOTAL SUM = " << SUM1;

	return 0;
}

