#include<iostream>
using namespace std;
int main()
{
	int D1 = 0; int M1 = 0; int Y1 = 0; char dash = 0; int age_months = 0; 
	int D2 = 0; int M2 = 0; int Y2 = 0; int age_days = 0; int age_years = 0; 
    
	cout << "hi ! this is a special calculator that will help you calculate the age of any person ! " << endl;
	cout << "just follow the given steps : " << endl;
	cout << "pls note : use 9 and 8 instead of 09 or 08" << endl;
	cout << endl;
	//input the required dates
	cout << "enter today's date (in the 00-00-00 format) : " << endl;
	cin >> D1 >> dash >> M1 >> dash >> Y1;
	cout << "enter the birth date of the person whose age you want to calculate (in the 00-00-00 format) : " << endl;
	cin >> D2 >> dash >> M2 >> dash >> Y2;

	//checking validity
	if (D1 > 31 || D2 > 31)
	{
		cout << "the day you entered is invalid" << endl;
	}
	if (M1 > 12 || M2 > 12)
	{
		cout << "the month you entered is invalid" << endl;
	}
	if (Y1 < Y2) 
	{
		cout << "the birth year you entered is invalid" << endl;
	}

	//calculating age
	if (D1 > D2 && M1>M2 && Y1>Y2)
	{
		age_days = D1 - D2; 
		age_months = M1 - M2;
		age_years = Y1 - Y2;
		cout << "AGE = " << age_days << " days " << age_months << " months " << age_years << " years " << endl;
	}

	//for when current date is smaller
	if ((D1 < D2) && M1 == 02 || M1 == 04 || M2 == 06 || M2 == 9 || M2 == 11 || M2==01 || M2 == 8)
	{
		age_days = (D1 + 31) - D2;
		M1 = M1 - 1;
		if (M1 < M2)
			age_months = (M1 + 12) - M2;
		Y1 = Y1 - 1;
		age_years = Y1 - Y2;
		cout << "AGE = " << age_days << " days " << age_months << " months " << age_years << " years " << endl;
	}
	
	if ((D1 < D2) && M1 == 03 || M1 == 05 || M2 == 07 || M2 == 10 || M2 == 12 )
	{
		age_days = (D1 + 30) - D2;
		M1 = M1 - 1;
		if (M1 < M2)
			age_months = (M1 + 12) - M2;
		Y1 = Y1 - 1;
		age_years = Y1 - Y2;
		cout << "AGE = " << age_days << " days " << age_months << " months " << age_years << " years " << endl;
	}
	
	
	
	return 0;
}