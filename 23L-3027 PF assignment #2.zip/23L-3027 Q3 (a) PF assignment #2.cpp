#include<iostream>
using namespace std;
int main()
{
	int N = 0; int n1 = 1; int n2 = 1;
	cout << "enter a number to check if it is a perfect square : ";
	cin >> N;
	while (N != -1 && n1 < N)
	{
		n1 = n2;
		if (n1 * n2 == N)
		{
			cout << "the number is a perfect square";
			break;
		}
		
		else if (n1 * n2 != N)
			n1++; n2++;
	}
	if (n1 * n2 != N)
		cout << "the number is not a perfect square";
	return 0;
}
