#include<iostream>
using namespace std;
int main()
{
	int term1 = 0;
	int term2 = 1;
	int next_term = 0;
	int N;
	cout << "enter the number uptil which you want to print the fibonacci sequence : ";
	cin >> N;
    cout << "fibonacci sequence upto < " << N << ":" << term1 << "," << term2;
	while (next_term < N)
	{
		next_term = term1 + term2;
		if ( next_term < N)
		cout << "," << next_term;
		term1 = term2;
		term2 = next_term;
	}
	return 0;
}