#include<iostream>
using namespace std;
int main()
{
	int N = 0; int n1 = 0; int n2 = 0; int n3 = 0; int prod = 0;
	cout << "enter your required number : ";
	cin >> N;
	int i = 1; int j = 2; int k = 3;
	while (i < N && j < N && k < N)
	{
		prod = i * j * k;
		if (prod == N)
		{
			n1 = i; n2 = j; n3 = k;
			cout << "number 1 = " << n1 << endl;
			cout << "number 2 = " << n2 << endl;
			cout << "number 3 = " << n3 << endl;
			break;
		}
		else if (prod != N)
		{
			i++; j++; k++;
		}

	}
	if (prod != N)
		cout << "NO 3- tuple of numbers";
	return 0;

}

