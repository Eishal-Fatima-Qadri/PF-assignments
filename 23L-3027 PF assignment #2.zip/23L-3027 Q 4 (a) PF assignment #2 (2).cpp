#include<iostream>
using namespace std;
int main()
{
	int N = 1000;

	for (int a = 0; a <= N; ++a) {
		for (int b = 0; b <= N - a; ++b) {
			for (int c = 0; c <= N - a - b; ++c) {

				int SUM = (a * a) + (b * b) + (c * c);
				if (SUM == N)
				{
					cout << a << "^2" << "+" << b << "^2" << "+" << c << "^2" << "=" << N << endl;
				}
			}
		}
	}
	return 0;
}

