#include<iostream>
using namespace std;
int main()
{
	int N1 = 0; int N2 = 0; int GCD = 0; int LCM = 0;
	cout << "enter two numbers" << endl;
	cin >> N1 >> N2;
	int i = 1;
	while (i <= N1 && i <= N2)
	{
		if (N1 % i == 0 && N2 % i == 0)
			GCD = i;
		i++;
	}
	LCM = (N1 * N2) / GCD;
	cout << "LCM = " << LCM;
	return 0;
}
	