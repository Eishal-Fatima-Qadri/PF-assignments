#include<iostream>
using namespace std;
int main()
{
	int N = 0;  char option = 0;
	char y; char Y;
	do
	{
		int n1 = 1; int n2 = 1;
		cout << "enter a number to check if it is a perfect square : ";
		cin >> N;

		while (N != -1 && n1 < N)
		{
			n1 = n2;
			if (n1 * n2 == N)
			{
				cout << "the number is a perfect square of " << n1 << endl;
				break;
			}

			else if (n1 * n2 != N)
				n1++; n2++;
		}

		if (n1 * n2 != N && N != -1)
			cout << "the number is not a perfect square" << endl;
		if (N == -1)
			cout << "invalid input" << endl;

		cout << "do you want to check another number? (Y/N)" << endl;
		cin >> option;

	} while (option == 'y' || option == 'Y');

	return 0;
}
