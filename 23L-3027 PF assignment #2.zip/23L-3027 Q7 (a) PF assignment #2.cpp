#include<iostream>
using namespace std;
int main()
{
	int N = 0; int num_position = 0;
	cout << "how many fibonacci numbers would you like to ask? :  ";
	cin >> N;
	cout << endl;
	
	//i : number of questions
	for (int i = 1; i <= N; i++)
	{
		cout << "Enter the position of the desired Fibonacci number: ";
		int num_position;
		cin >> num_position;


		long long next_term = 0; long long term1 = 1; long long term2 = 1;


		if (num_position <= 0) {
			cout << "invalid input. position must be a positive integer." << endl;
		}
		else if (num_position == 1) {
			cout << "fibonacci(" << num_position << ") = " << term1 << endl;
		}
		else if (num_position == 2) {
			cout << "Fibonacci(" << num_position << ") = " << term2 << endl;
		}

        // j: determine number by position
		else if (num_position > 2)
		{
			for (int j = 3; j <= num_position; j++)
			{
				next_term = term1 + term2;
				term1 = term2;
				term2 = next_term;
			}
			cout << "fibonacci(" << num_position << ") = " << next_term << endl;
		}
	}
	return 0;

}