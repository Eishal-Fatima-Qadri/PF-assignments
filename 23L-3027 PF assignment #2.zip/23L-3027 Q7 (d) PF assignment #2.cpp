#include<iostream>
using namespace std;
int main()
{
	long long term1 = 0;
	long long term2 = 1;
	long long next_term = 0;
	int sum = 0;
	
	
	while (next_term < 4000000)
	{
		next_term = term1 + term2;
		term1 = term2;
		term2 = next_term;
	
	if (next_term % 2 == 0)
		sum = sum + next_term;

    }

	cout << "sum = " << sum;
	return 0;
}