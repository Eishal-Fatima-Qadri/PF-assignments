#include<iostream>
using namespace std;
int main()
{
	 int x = 0;  int y = 0;
	 int a = 0;  int b = 0;
     int p = 0;  int q = 0;
	 int s = 0;  int t = 0;
     int x1 = 0; int y1 = 0;
	int MAX_xlimit = 0; int MAX_ylimit = 0;

	cout << "enter the four coordinates of your rectangle" << endl;
	cout << "p1 = ( , )";
	cin >> x >> y;
	cout << "p2 = ( , )";
	cin >> a >> b;
	cout << "p3 = ( , )";
	cin >> p >> q;
	cout << "p4 = ( , )";
	cin >> s >> t;

	MAX_xlimit = (x, a, p, s);
	MAX_ylimit = (y, b, q, t);

	cout << "enter the point whose position you want to check"<<endl;
	cout << "P = ( , )";
	cin >> x1 >> y1;

	if (x1 >= MAX_xlimit || y1 >= MAX_ylimit )
	{
		cout << "the point lies outside the rectangle";
	}
	else if (x1 <= x, a, p, s || y1 <= y, b, q, t)
	{
		cout << "the point lies inside the rectangle";
	}
	return 0;
}





















