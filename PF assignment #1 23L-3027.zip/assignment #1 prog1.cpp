#include<iostream>
using namespace std;
int main()
{
	int a;
	int b;
	int c;
	cout << "please enter 3 integer numbers"; 
	cin >> a >> b >> c;
	cout << "DESCENDING :" << endl;;
	if ((a > b) && (a > c))
	{
		if (b > c)
		{
			cout << a << endl;
			cout << b << endl;
			cout << c << endl;
		}

		else 
		{
			cout  << a << endl;
			cout  << c << endl;
			cout  << b << endl;
		}


	}
	else if ((b > a) && (b > c))
	{
		if (a > c)
		{
			cout << b << endl;
			cout << a << endl;
			cout << c << endl;
		}
		else 
		{
			cout  << b << endl;
			cout  << c << endl;
			cout  << a << endl;
		}
	}
	else if ((c > a) && (c > b))
	{
		if (a > b)
		{
			cout  << c << endl;
			cout  << a << endl;
			cout  << b << endl;
		}
		else 
		{
			cout  << c << endl;
			cout  << b << endl;
			cout  << a << endl;
		}
	}
	cout << "ASCENDING :" << endl;;
	if ((a < b) && (a < c)) //ascending
	{
		if (b < c)
		{
			cout << a << endl;
			cout << b << endl;
			cout << c << endl;
		}

		else
		{
			cout << a << endl;
			cout << c << endl;
			cout << b << endl;
		}


	}
	else if ((b < a) && (b < c))
	{
		if (a < c)
		{
			cout << b << endl;
			cout << a << endl;
			cout << c << endl;
		}
		else
		{
			cout << b << endl;
			cout << c << endl;
			cout << a << endl;
		}
	}
	else if ((c < a) && (c < b))
	{
		if (a < b)
		{
			cout << c << endl;
			cout << a << endl;
			cout << b << endl;
		}
		else
		{
			cout << c << endl;
			cout << b << endl;
			cout << a << endl;
		}
	}
	else
	{
		cout << "ALL numbers are equal";
	}
	return 0;
}
