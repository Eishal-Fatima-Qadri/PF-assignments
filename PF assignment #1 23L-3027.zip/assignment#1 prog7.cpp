#include<iostream>
using namespace std;
int main()
{
	int a = 0, b = 0, c = 0;
	int a_sq = 0, b_sq = 0, c_sq = 0;
	cout << "enter 3 numbers" << endl;
	cin >> a >> b >> c;
	a_sq = a * a;
	b_sq = b * b;
	c_sq = c * c;
	if (a>b && a>c && a_sq == b_sq + c_sq)
	{
			cout << "the three numbers are pythagorean triple";
	}
	else if (b > c && b>a && b_sq == a_sq + c_sq)
	{	cout << "the three numbers are pythagorean triple";
	}
	else if (c > b && c > a && c_sq == b_sq + a_sq)
	{
			cout << "the three numbers are pythagorean triple";
	}
	else
		cout << "the three numbers are not pythagorean triple";
	return 0;
}