﻿#include<iostream>
using namespace std;
int main()
{
	int CODE = 0;
	int QUANTITY = 0;
	int PRICE = 0;
	int CURRENCY = 0;
	int STAX = 0;
	int TOTALPRICE = 0;
	//menu
	cout << "CODE          " << " MEALS              " << "PRICE IN RUPPEE PER KG" << endl;
	cout << "1             " << "chicken handi       " << "1800" << endl;
	cout << "2             " << "chicken karahi      " << "2000" << endl;
	cout << "3             " << "chicken tikka       " << "2200" << endl;
	cout << "4             " << "chicken haleem      " << "500" << endl;
	cout << "5             " << "creamy chicken      " << "2500" << endl;
	cout << "---------------------------------------------------------------------------"<<endl;
	//meal selection
	cout << "★ please enter the code of the meal you want to buy :" << endl; ;
	cin >> CODE;
	if (CODE == 1)
	{

		cout << "- The dish you selected is 'chicken handi'" << endl;
	}
	else if (CODE == 2)
	{

		cout << "- The dish you selected is 'chicken karahi'" << endl;
	}
	else if (CODE == 3)
	{
		cout << "- The dish you selected is 'chicken tikka'" << endl;
	}
	else if (CODE == 4)
	{
		cout << "- The dish you selected is 'chicken haleem'" << endl;
	}
	else if (CODE == 5)
	{
		cout << "- The dish you selected is 'creamy chicken'" << endl;
	}
	else
	{
		cout << "the code you entered is invalid" << endl;
		return 1;
	}
	cout << "---------------------------------------------------------------------------"<<endl;
	//quantity
	cout << "★ please enter the quantity of your dish in kilograms :";
	cin >> QUANTITY;
	if (QUANTITY < 0)
	{
		cout << "invalid quantity";
	}
	//PRICE
	if (CODE == 1)
	{
		PRICE = 1800 * QUANTITY;
	}
	else if (CODE == 2)
	{
		PRICE = 2000 * QUANTITY;
	}
	else if (CODE == 3)
	{
		PRICE = 2200 * QUANTITY;
	}
	else if (CODE == 4)
	{
		PRICE = 500 * QUANTITY;
	}
	else if (CODE == 5)
	{
		PRICE = 2500 * QUANTITY;
	}


	// total price and tax
	if (PRICE <= 1000) {
		STAX = 0;
	}
	else if (PRICE > 1000 && PRICE <= 3000) {
		STAX = PRICE * 2 / 100;
	}
	else if (PRICE > 3000) {
		STAX = PRICE * 5 / 100;
	}
	cout << "---------------------------------------------------------------------------"<<endl;
	//CURRENCY
	cout << "★ which currency would you like to use? enter 1 for ruppee,2 for euro or 3 for dollar" << endl;
	cin >> CURRENCY;
	if (CURRENCY == 1)
	{
		cout << "the selected currency is ruppee" << endl;
		cout << "sales tax=RS" << STAX<<endl;
		TOTALPRICE = PRICE + STAX;
		cout << "TOTALPRICE=RS" << TOTALPRICE << endl;

	}
	else if (CURRENCY == 2)
	{
		cout << "the selected currency is euro" << endl;
		STAX = STAX * 1 / 193;
		cout << "sales tax=€" << STAX<<endl;
		TOTALPRICE = (PRICE * 1 / 193) + STAX;
		cout << "TOTALPRICE=€" << TOTALPRICE << endl;

	}
	else if (CURRENCY == 3)
	{
		cout << "the selected currency is dollar" << endl;
		STAX = STAX * 1 / 165;
		cout << "sales tax=$" << STAX<<endl;
		TOTALPRICE = (PRICE * 1 / 165) + STAX;
		cout << "TOTALPRICE=$" << TOTALPRICE << endl;

	}
	else
	{
		cout << "invalid input";
	}
	return 0;
}

	
  
   








	