﻿#include<iostream>
using namespace std;
int main()
{
	char CHOICE1 = 0;
	char CHOICE2 = 0;
	char R = 0;
	char P = 0;
	char S = 0;
	cout << "★ RULES : enter R for rock, P for paper and S for scissors" << endl;
	cout << "----------------------------------------------------------------------"<<endl;
	cout << "★ PLAYER 1 and PLAYER 2 please enter your choices"<<endl;
	cin >> CHOICE1>> CHOICE2;
	cout << "----------------------------------------------------------------------"<<endl;
	switch (CHOICE1)
	{
	case'R':
		if (CHOICE2 == 'S')
		{
			cout << "player 1 wins !";
		}
		else
			cout << "player 2 wins !";
		break;
	case 'S':
		if (CHOICE2 == 'P')
		{
			cout << "player 1 wins !"; 
		}
		else
			cout << "player 2 wins !";
		break;
	case 'P':
		if (CHOICE2 == 'R')
		{
			cout << "player 1 wins !"; 
		}
		else
			cout << "player 2 wins !";
		break;

	    default:
			cout << "invalid choice";
	}
	return 0;
}