#include<iostream>
using namespace std;
int main()
{
	int p1 = 0; int x = 0;  int y = 0;
	int p2 = 0; int a = 0;  int b = 0;
	int p3 = 0; int p = 0;  int q = 0;
	float S1 = 0;
	float S2 = 0;
	float S3 = 0;
	float S1_sq = 0; float S2_sq = 0; float S3_sq = 0;
	p1 = (x, y);
	p2 = (a, b);
	p3 = (p, q);
	cout << "enter three points" << endl;
	cout << "p1 = ( , )";
	cin >> x >> y;
	cout << "p2 = ( , )";
	cin >> a >> b;
	cout << "p3 = ( , )";
	cin >> p >> q;
	S1 = (((a - x) * (a - x)) + ((b - y) * (b - y))) / S1;
	S2 = (((p - a) * (p - a)) + ((q - b) * (q - b))) / S2;
	S3 = (((x - p) * (x - p)) + ((y - q) * (y - q))) / S3;
	if (S1 == 0 || S2 == 0 || S3 == 0)
	{
		cout << "invalid lenght. distance can never be zero" << endl;
		cout << "enter the 3 points again";
		cout << "p1 = ( , )";
		cin >> x, y;
		cout << "p2 = ( , )";
		cin >> a, b;
		cout << "p3 = ( , )";
		cin >> p, q;
	}
	S1_sq = S1 * S1;
	S2_sq = S2 * S2;
	S3_sq = S3 * S3;
	if (S1 > S2 && S1 > S3 && S1_sq == S2_sq + S3_sq)
	{
		cout << "it is a right angle triangle triangle";
	}
	else if (S2 > S1 && S2 > S3 && S2_sq == S1_sq + S3_sq)
	{
		cout << "it is a right angle triangle triangle";
	}
	else if (S3 > S1 && S3 > S2 && S3_sq == S1_sq + S2_sq)
	{
		cout << "it is a right angle triangle triangle";
	}

	if (S1 == S2 && S2 == S3 && S3 == S1)
	{
		cout << "it is an equilateral triangle";
	}
	else if (S1 == S2 || S2 == S3 || S3 == S1) {
		cout << "it is an isosceles triangle";
	}
	else if (S1 != S2 && S2 != S3 && S3 != S1) {
		cout << "it is a scalene triangle";
	}
	return 0;
}