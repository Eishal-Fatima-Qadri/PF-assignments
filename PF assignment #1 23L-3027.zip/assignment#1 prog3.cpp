#include<iostream>
using namespace std;
int main()
{
	int NUMBER = 0;

	cout << "enter a number having at most six digits";
	cin >> NUMBER;
	if ((NUMBER < 1) || (NUMBER > 999999))
	{
		cout << "wrong input" << endl;
		return 1;
	}
	int digit1 = NUMBER / 100000;
	int digit2 = (NUMBER / 10000) % 10;
	int digit3 = (NUMBER / 1000) % 10;
	int digit4 = (NUMBER / 100) % 10;
	int digit5 = (NUMBER / 10) % 10;
	int digit6 = NUMBER % 10;

	//for digit 1
	if (digit1 != 0)
	{
		switch (digit1)
		{
		case 1:
			cout << "one\t"; break;
		case 2:
			cout << "two\t"; break;
		case 3:
			cout << "three\t"; break;
		case 4:
			cout << "four\t"; break;
		case 5:
			cout << "five\t"; break;
		case 6:
			cout << "six\t"; break;
		case 7:
			cout << "seven\t"; break;
		case 8:
			cout << "eight\t"; break;
		case 9:
			cout << "nine\t"; break;
		}
	}

	//for digit 2
	switch (digit2)
	{
	case 0:
		if (digit1 != 0)
		{
			cout << "zero\t";
		}
		break;
	case 1:
		cout << "one\t"; break;
	case 2:
		cout << "two\t"; break;
	case 3:
		cout << "three\t"; break;
	case 4:
		cout << "four\t"; break;
	case 5:
		cout << "five\t"; break;
	case 6:
		cout << "six\t"; break;
	case 7:
		cout << "seven\t"; break;
	case 8:
		cout << "eight\t"; break;
	case 9:
		cout << "nine\t"; break;
	}

	//for digit 3
	switch (digit3)
	{

	case 0:
		if (digit2 != 0 || digit1 != 0)
		{
			cout << "zero\t";
		}
		break;
	case 1:
		cout << "one\t"; break;
	case 2:
		cout << "two\t"; break;
	case 3:
		cout << "three\t"; break;
	case 4:
		cout << "four\t"; break;
	case 5:
		cout << "five\t"; break;
	case 6:
		cout << "six\t"; break;
	case 7:
		cout << "seven\t"; break;
	case 8:
		cout << "eight\t"; break;
	case 9:
		cout << "nine\t"; break;
	}

	//for digit 4
	switch (digit4)
	{
	case 0:
		if (digit3 != 0 || digit2 != 0 || digit1 != 0)

		{
			cout << "zero\t";
		}
		break;
	case 1:
		cout << "one\t"; break;
	case 2:
		cout << "two\t"; break;
	case 3:
		cout << "three\t"; break;
	case 4:
		cout << "four\t"; break;
	case 5:
		cout << "five\t"; break;
	case 6:
		cout << "six\t"; break;
	case 7:
		cout << "seven\t"; break;
	case 8:
		cout << "eight\t"; break;
	case 9:
		cout << "nine\t"; break;
	}

	//for digit 5
	switch (digit5)
	{
	case 0:
		if (digit4 != 0 || digit3 != 0 || digit2 != 0 || digit1 != 0)

		{
			cout << "zero\t";
		}
		break;
	case 1:
		cout << "one\t"; break;
	case 2:
		cout << "two\t"; break;
	case 3:
		cout << "three\t"; break;
	case 4:
		cout << "four\t"; break;
	case 5:
		cout << "five\t"; break;
	case 6:
		cout << "six\t"; break;
	case 7:
		cout << "seven\t"; break;
	case 8:
		cout << "eight\t"; break;
	case 9:
		cout << "nine\t"; break;
	}

	//for digit 6
	switch (digit6)
	{
	case 0:
		if (digit5 != 0 || digit4 != 0 || digit3 != 0 || digit2 != 0 || digit1 != 0)
		{
			cout << "zero\t";
		}
		break;
	case 1:
		cout << "one\t"; break;
	case 2:
		cout << "two\t"; break;
	case 3:
		cout << "three\t"; break;
	case 4:
		cout << "four\t"; break;
	case 5:
		cout << "five\t"; break;
	case 6:
		cout << "six\t"; break;
	case 7:
		cout << "seven\t"; break;
	case 8:
		cout << "eight\t"; break;
	case 9:
		cout << "nine\t"; break;
	}

	system("pause");
	return 0;

}



