#include <iostream>
using namespace std;

// Function to find and display the frequency of each element in the array
void finding_frequency(int array[], int total_elements)
{
    for (int i = 0; i < total_elements; i++)
    {
        if (array[i] > 0)
        {
            cout << "The frequency of " << i << " is " << array[i] << endl;
        }
    }
}

int main()
{
    int size = 20;
    int array[size] = { 0 };   //declare an array having all elements set to 0
    int n = 0;

    cout << "Enter the elements of the array (enter -99 to stop the input): " << endl;
    int total_elements = 0;

    for (int i = 0; (i < size && n != -99); i++)
    {
        cin >> n;

        // Check if the input is negative and not equal to -99
        if (n < 0 && n != -99)
        {
            cout << "Invalid input" << endl;
        }

        if (n > 0)
        {
            // Increment the frequency of the element in the array
            array[n]++;
        }

        total_elements++;
    }

    // Call the function to find and display the frequency of elements
    finding_frequency(array, total_elements);

    return 0;
}