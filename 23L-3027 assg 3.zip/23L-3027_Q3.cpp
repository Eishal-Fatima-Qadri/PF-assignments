#include<iostream>
using namespace std;
int main()
{
	int s = 0, n = 0;
	cout << "enter the size of your array (containing only zeros and ones) : " << endl; //ask the user for the size of an array consisting of only zeros and ones
	cin >> s;
	int array[s];
	cout << "enter the 0 and 1 sequence : " << endl; //ask for the 0,1 sequence

	for (int i = 0; i < s; i++)
	{
		cin >> n;
		if (n < 0 || n >1)
		{
			s = i;
			break;
		}
		array[i] = n;
	}

	// use a nested loop to perform bubble sort to shift 0s to the left and 1s to the right

	for (int i = 0; i < s - 1; i++) {     // elements starting from index 0 uptil the second last element
		for (int j = i + 1; j < s; j++) {  // elements starting from index i+1 uptil the last element
			if (array[i] == 0)
			{                            //check for the presence of a zero.
				array[i] = array[i];
			}
			else if (array[i] == 1)
			{                           // swap positions when a 1 is found on the left of a zero.
				int swap = array[j];
				array[j] = array[i];
				array[i] = swap;
			}
		}

	}
	cout << "the segregated array = "; // print the segregated array

	for (int i = 0; i < s; i++) {
		cout << array[i] << " ";
	}
	return 0;

}