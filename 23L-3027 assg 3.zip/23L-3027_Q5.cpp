#include<iostream>
using namespace std;
int main()
{
	int s = 0; int new_ele = 0; int new_index = 0;

	// ask for the size and elements in the array
	cout << "enter the size of the array : ";
	cin >> s;
	int array[s];
	cout << "enter the " << s << " elements of the array : " << endl;
	for (int i = 0; i < s; i++)
	{
		cin >> array[i];
	}
	// ask for the new element and the corresponding index
	cout << "enter the element that you wish to add : ";
	cin >> new_ele;
	cout << "and at what index? : ";
	cin >> new_index;

	// incase the user enters an invalid index

	if (new_index <0 || new_index >s)
	{
		cout << "invalid index.It should be between 0 and" << s << endl;
	}

	// shifting all elements present after the entered index to make space for the new element
	for (int k = s; k > new_index; k--)
	{
		array[k] = array[k - 1];
	}

	// add the new element and increase the size
	array[new_index] = new_ele;
	s++;

	//print the new array
	for (int i = 0; i < s; i++)
	{
		cout << "updated array = " << array[i] << " ";
	}
	return 0;
}
