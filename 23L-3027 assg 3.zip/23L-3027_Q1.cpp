#include<iostream>
using namespace std;

//make a function to find the triplets
void find_triplets(int array[], int s, int n)
{
	int sum = 0;
	int count = 0;
	for (int i = 0; i < s - 2; i++)  // start off with the element at the first index (i) 
	{
		for (int j = i + 1; j < s - 1; j++)  // j = elements after i upto the second last element
		{
			for (int k = j + 1; k < s; k++)  // k = elements after j upto the last element
			{
				sum = array[i] + array[j] + array[k];  // calculate sum of the elements at i,j and k
				if (sum == n)
				{
					cout << "The triplets that make up " << n << " are " << array[i] << " , " << array[j] << " , " << array[k] << endl;
					count++;
				}

			}
		}
	}
	if (count == 0) //incase there's no increment in the count variable
	{
		cout << "no triplets found ";
	}
}
int main()
{
	int n = 0;
	int array[] = { 43,50,67,99,10,19,56,4,23,45 }; //hardcode the array
	int array_size = 10;
	cout << "enter a positive integer number : "; //ask for the number whose triplets need to be checked
	cin >> n;

	find_triplets(array, array_size, n); //call the triplet finding function
	return 0;


}