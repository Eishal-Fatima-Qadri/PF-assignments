#include <iostream>
using namespace std;

// Function to find and print prime numbers in the array
int prime_array(int array[], int size)
{
    for (int i = 0; i < size; i++)
    {
        int track = 0;
        // Check for factors of the array element
        for (int j = 2; j <= size; j++)
        {
            if (array[i] % j == 0 && array[i] > 1)
            {
                track++;
            }
        }

        // If there's only one factor (itself), it's a prime number
        if (track == 1)
        {
            cout << array[i] << " ";
        }
    }
}

// Function to find and print Fibonacci numbers in the array
int fibonacci_array(int array[], int size)
{
    int term1 = 0;
    int term2 = 1;
    for (int i = 0; i <= size; i++)
    {
        int next_term = 0;
        // Calculate the next Fibonacci term
        next_term = term1 + term2;
        term1 = term2;
        term2 = next_term;
        // If it matches an element in the array, it's a Fibonacci number
        if (array[i] == next_term)
            cout << array[i] << " ";
    }
}

// Function to find and print numbers that are neither prime nor Fibonacci in the array
void non_prime_fibo(int array[], int size)
{
    int track = 0;
    for (int i = 0; i < size; i++)
    {
        for (int j = 2; j < 100; j++)
        {
            if (array[i] % j == 0)
                track++;
        }

        int term1 = 0;
        int term2 = 1;
        int next_term = 0;
        for (int i = 0; i < 100; i++)
        {
            // Calculate the next Fibonacci term
            next_term = term1 + term2;
            term1 = term2;
            term2 = next_term;
        }

        // If not a prime number and not a Fibonacci number, it's printed
        if ((track != 1) && (array[i] != next_term))
        {
            cout << array[i] << " ";
        }
    }
}

int main()
{
    int size = 0;
    cout << "Enter the size of your array: ";
    cin >> size;
    int array[size];
    cout << "Enter the elements: " << endl;
    for (int i = 0; i < size; i++)
    {
        cin >> array[i];
    }

    // Call the functions to find and print prime, Fibonacci, and non-prime/non-Fibonacci numbers
    prime_array(array, size);
    fibonacci_array(array, size);
    non_prime_fibo(array, size);

    return 0;
}

	
