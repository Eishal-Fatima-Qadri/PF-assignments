#include <iostream>
using namespace std;

// Function to reverse a single word in place
void reverseWord(char word[], int start, int end) {
    while (start < end) {
        // Swap characters at start and end indices
        char temp = word[start];
        word[start] = word[end];
        word[end] = temp;

        // Move indices towards each other
        start++;
        end--;
    }
}

// Function to reverse each word in the given sentence
void reverseWords(char sentence[], char reversedSentence[]) {
    int start = 0, end = 0;
    int reversedIndex = 0;

    while (sentence[end] != '\0') {
        if (sentence[end] == ' ') {
            //  boundary found
            reverseWord(sentence, start, end - 1);  // Reverse the current word and add it to the reversed sentence array

            for (int i = start; i < end; i++) {
                reversedSentence[reversedIndex] = sentence[i];
                reversedIndex++;
            }

            // Add a space after the reversed word
            reversedSentence[reversedIndex] = ' ';
            reversedIndex++;

            // Move to the next word
            start = end + 1;
        }

        // Move to the next character in the sentence
        end++;
    }

    // Reverse the last word in the sentence
    reverseWord(sentence, start, end - 1);

    // add the last word to the reversed sentence array
    for (int i = start; i < end; i++) {
        reversedSentence[reversedIndex] = sentence[i];
        reversedIndex++;
    }

    // Add null terminator at the end of the reversed sentence array
    reversedSentence[reversedIndex] = '\0';
}

int main() {
    const int size = 100;
    char inputSentence[size];
    char reversedSentence[size];

    cout << "Enter your sentence: " << endl;
    cin.getline(inputSentence, size);

    reverseWords(inputSentence, reversedSentence);

    cout << "Reversed sentence: " << reversedSentence << endl;

    return 0;
}
